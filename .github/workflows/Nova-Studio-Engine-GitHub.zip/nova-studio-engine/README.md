# Nova Studio Engine

**Nova Studio** é um projeto experimental de ambiente de criação 3D para navegador, com fluxo de trabalho inspirado em editores de desenvolvimento: projetos, viewport, hierarquia, propriedades e ferramentas.

> Este repositório contém a fundação inicial do editor. Não é uma engine completa nem uma cópia do Roblox Studio.

## Estado atual

- [x] Tela de entrada com perfil local
- [x] Hub de projetos recentes
- [x] Criação e abertura de projetos
- [x] Viewport 3D com Three.js
- [x] Câmera orbital
- [x] Grade e iluminação
- [x] Adicionar e excluir cubos
- [x] Selecionar objetos
- [x] Ferramentas de mover, rotacionar e escalar
- [x] Inspetor básico de propriedades
- [x] Salvar e carregar cena no armazenamento local do navegador
- [ ] Autenticação real e contas
- [ ] Sincronização em nuvem
- [ ] Sistema de arquivos de projeto/importação/exportação
- [ ] Undo/Redo
- [ ] Runtime isolado para executar jogos
- [ ] Editor de scripts com execução segura
- [ ] Física, animação, áudio e assets avançados

## Executar

A aplicação usa módulos ES e importa Three.js por CDN. Abra o projeto por um servidor HTTP local ou publique no GitHub Pages/Netlify. Abrir `index.html` diretamente como `file://` pode bloquear módulos no navegador.

### GitHub Pages
1. Crie um repositório no GitHub.
2. Envie todos os arquivos mantendo a estrutura de pastas.
3. Em **Settings → Pages**, selecione a branch principal e a pasta `/ (root)`.
4. Aguarde a publicação e abra a URL fornecida.

## Estrutura

```text
nova-studio-engine/
├── index.html
├── README.md
└── src/
    ├── main.js
    ├── studio.js
    ├── scene-editor.js
    └── styles.css
```

## Observações técnicas

- Os projetos são armazenados em `localStorage` no navegador e ficam restritos ao dispositivo/perfil do navegador.
- O campo de perfil é local e **não é autenticação**. Não insira senhas ou dados sensíveis.
- A dependência Three.js é carregada por CDN; é necessária conexão com a internet para carregar a biblioteca.
- O modo Testar atual é apenas um estado visual do editor, ainda não executa um jogo independente.
- Esta base deve ser testada em navegadores móveis reais antes de ser considerada estável.

## Licença

MIT — consulte `LICENSE`.
