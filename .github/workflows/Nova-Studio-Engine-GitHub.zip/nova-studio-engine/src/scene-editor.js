import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { TransformControls } from "three/addons/controls/TransformControls.js";

export class SceneEditor {
  constructor({ onChange, onLog }) {
    this.onChange = onChange;
    this.onLog = onLog;
    this.scene = null;
    this.renderer = null;
    this.camera = null;
    this.controls = null;
    this.transform = null;
    this.selected = null;
    this.tool = "select";
    this.playing = false;
    this.gridVisible = true;
    this.objects = [];
    this.pointer = new THREE.Vector2();
    this.raycaster = new THREE.Raycaster();
    this.animate = this.animate.bind(this);
  }

  mount(container, savedScene) {
    this.container = container;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color("#171e2a");
    this.scene.fog = new THREE.Fog("#171e2a", 22, 70);
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 500;
    this.camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 500);
    this.camera.position.set(8, 7, 10);
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    this.renderer.setSize(width, height);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.prepend(this.renderer.domElement);

    this.scene.add(new THREE.HemisphereLight(0xdce8ff, 0x343b4b, 2.0));
    const keyLight = new THREE.DirectionalLight(0xffffff, 2.2);
    keyLight.position.set(7, 12, 8);
    keyLight.castShadow = true;
    this.scene.add(keyLight);

    this.grid = new THREE.GridHelper(40, 40, 0x596b8a, 0x303b50);
    this.scene.add(this.grid);
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(200, 200), new THREE.MeshStandardMaterial({ color: 0x202938, roughness: 0.95 }));
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -0.025;
    floor.receiveShadow = true;
    floor.name = "Base";
    floor.userData.locked = true;
    this.scene.add(floor);
    this.objects = [];

    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.target.set(0, 1, 0);
    this.transform = new TransformControls(this.camera, this.renderer.domElement);
    this.transform.addEventListener("dragging-changed", (e) => { this.controls.enabled = !e.value; });
    this.transform.addEventListener("objectChange", () => this.onChange());
    this.scene.add(this.transform);

    this.renderer.domElement.addEventListener("pointerdown", (e) => this.pick(e));
    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(container);
    if (savedScene?.objects?.length) this.restore(savedScene);
    else this.addCube(false);
    this.running = true;
    this.animate();
    this.updateProperties();
  }

  animate() {
    if (!this.running) return;
    requestAnimationFrame(this.animate);
    this.controls?.update();
    this.renderer?.render(this.scene, this.camera);
  }

  resize() {
    if (!this.renderer || !this.container) return;
    const w = this.container.clientWidth, h = this.container.clientHeight;
    if (!w || !h) return;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  }

  addCube(mark = true) {
    const index = this.objects.length + 1;
    const mesh = new THREE.Mesh(
      new THREE.BoxGeometry(2, 2, 2),
      new THREE.MeshStandardMaterial({ color: new THREE.Color().setHSL((index * 0.13) % 1, 0.42, 0.58), roughness: 0.65 })
    );
    mesh.position.set((index - 1) % 3 * 2.6 - 1.3, 1, Math.floor((index - 1) / 3) * 2.6);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    mesh.name = `Part ${index}`;
    this.scene.add(mesh);
    this.objects.push(mesh);
    this.select(mesh);
    if (mark) { this.onLog(`Objeto ${mesh.name} adicionado.`); this.onChange(); }
  }

  getObjects() { return this.objects; }

  pick(event) {
    if (this.transform?.dragging) return;
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    this.pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
    this.raycaster.setFromCamera(this.pointer, this.camera);
    const hits = this.raycaster.intersectObjects(this.objects, false);
    this.select(hits.length ? hits[0].object : null);
  }

  select(object) {
    this.selected = object;
    if (object) this.transform.attach(object);
    else this.transform.detach();
    this.updateProperties();
    this.onChange();
  }

  setTool(tool) {
    this.tool = tool;
    if (tool === "move" || tool === "rotate" || tool === "scale") {
      this.transform.setMode({ move: "translate", rotate: "rotate", scale: "scale" }[tool]);
      this.transform.showX = this.transform.showY = this.transform.showZ = true;
      if (this.selected) this.transform.attach(this.selected);
    } else {
      this.transform.detach();
    }
  }

  deleteSelected() {
    if (!this.selected) return;
    const name = this.selected.name;
    this.transform.detach();
    this.scene.remove(this.selected);
    this.selected.geometry.dispose();
    this.selected.material.dispose();
    this.objects = this.objects.filter((o) => o !== this.selected);
    this.selected = null;
    this.updateProperties();
    this.onLog(`${name} removido.`);
    this.onChange();
  }

  focusSelected() {
    if (!this.selected) return;
    this.controls.target.copy(this.selected.position);
    const offset = new THREE.Vector3(6, 5, 7);
    this.camera.position.copy(this.selected.position).add(offset);
  }

  toggleGrid() {
    this.gridVisible = !this.gridVisible;
    this.grid.visible = this.gridVisible;
    return this.gridVisible;
  }

  updateProperties() {
    const host = document.getElementById("propertiesContent");
    const type = document.getElementById("selectedType");
    if (!host || !type) return;
    if (!this.selected) {
      type.textContent = "Nenhum";
      host.innerHTML = '<div class="property-empty">Selecione um objeto para editar suas propriedades.</div>';
      return;
    }
    const obj = this.selected;
    type.textContent = "Mesh";
    const vec = (label, key, values) => `<div class="property-row"><span>${label}</span><div class="vector-fields">${values.map((v, i) => `<input data-vector="${key}" data-index="${i}" type="number" step="0.1" value="${Number(v).toFixed(2)}">`).join("")}</div></div>`;
    host.innerHTML = `<div class="property-group">GERAL</div><div class="property-row"><span>Nome</span><input id="propName" value="${this.escape(obj.name)}"></div><div class="property-group">TRANSFORMAÇÃO</div>${vec("Posição","position",obj.position.toArray())}${vec("Rotação","rotation",obj.rotation.toArray().slice(0,3).map(v=>THREE.MathUtils.radToDeg(v)))}${vec("Escala","scale",obj.scale.toArray())}<div class="property-group">APARÊNCIA</div><div class="property-row"><span>Cor</span><input id="propColor" type="color" value="#${obj.material.color.getHexString()}"></div><div class="property-row"><span>Visível</span><input id="propVisible" type="checkbox" ${obj.visible ? "checked" : ""}></div>`;
    document.getElementById("propName").addEventListener("change", (e) => { obj.name = e.target.value.trim() || "Part"; this.onChange(); });
    document.getElementById("propColor").addEventListener("input", (e) => { obj.material.color.set(e.target.value); this.onChange(); });
    document.getElementById("propVisible").addEventListener("change", (e) => { obj.visible = e.target.checked; this.onChange(); });
    host.querySelectorAll("[data-vector]").forEach((input) => input.addEventListener("change", () => {
      const key = input.dataset.vector, idx = Number(input.dataset.index);
      const values = key === "rotation"
        ? obj.rotation.toArray().slice(0, 3).map((v) => THREE.MathUtils.radToDeg(v))
        : obj[key].toArray();
      values[idx] = Number(input.value) || 0;
      if (key === "rotation") values.forEach((v, i) => values[i] = THREE.MathUtils.degToRad(v));
      obj[key].fromArray(values);
      obj.updateMatrixWorld();
      this.onChange();
    }));
  }

  serialize() {
    return { objects: this.objects.map((o) => ({ name:o.name, position:o.position.toArray(), rotation:o.rotation.toArray(), scale:o.scale.toArray(), color:o.material.color.getHexString(), visible:o.visible })) };
  }

  restore(data) {
    data.objects.forEach((item) => {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(2,2,2), new THREE.MeshStandardMaterial({ color: `#${item.color || "8ca9ff"}`, roughness:0.65 }));
      mesh.name = item.name || "Part";
      mesh.position.fromArray(item.position || [0,1,0]);
      mesh.rotation.fromArray(item.rotation || [0,0,0, "XYZ"]);
      mesh.scale.fromArray(item.scale || [1,1,1]);
      mesh.visible = item.visible !== false;
      mesh.castShadow = true;
      this.scene.add(mesh);
      this.objects.push(mesh);
    });
    this.select(this.objects[0] || null);
  }

  togglePlay() {
    this.playing = !this.playing;
    const button = document.getElementById("playProject");
    button.textContent = this.playing ? "■ Parar teste" : "▶ Testar";
    button.classList.toggle("playing", this.playing);
    this.onLog(this.playing ? "Modo de teste visual iniciado." : "Modo de teste encerrado.");
  }

  unmount() {
    this.running = false;
    this.resizeObserver?.disconnect();
    this.controls?.dispose();
    this.transform?.dispose?.();
    this.renderer?.dispose();
    this.renderer?.domElement.remove();
    this.scene = null;
    this.renderer = null;
    this.objects = [];
    this.selected = null;
  }

  escape(value) {
    return String(value).replace(/[&<>"']/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  }
}
