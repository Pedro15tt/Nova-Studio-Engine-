import { SceneEditor } from "./scene-editor.js";

const $ = (id) => document.getElementById(id);
const STORAGE_KEY = "nova-studio-projects-v1";
const PROFILE_KEY = "nova-studio-profile-v1";

export class StudioApp {
  constructor() {
    this.profile = localStorage.getItem(PROFILE_KEY) || "";
    this.projects = this.readProjects();
    this.activeProjectId = null;
    this.editor = new SceneEditor({
      onChange: () => this.markDirty(),
      onLog: (message) => this.log(message)
    });
  }

  start() {
    $("enterStudio").addEventListener("click", () => this.enter());
    $("profileName").addEventListener("keydown", (e) => { if (e.key === "Enter") this.enter(); });
    $("switchProfile").addEventListener("click", () => this.showWelcome());
    $("newProject").addEventListener("click", () => this.createProjectDialog());
    $("emptyNewProject").addEventListener("click", () => this.createProjectDialog());
    $("backToHub").addEventListener("click", () => this.backToHub());
    $("saveProject").addEventListener("click", () => this.saveActive());
    $("playProject").addEventListener("click", () => this.editor.togglePlay());
    $("addCube").addEventListener("click", () => this.editor.addCube());
    $("deleteObject").addEventListener("click", () => this.editor.deleteSelected());
    $("focusView").addEventListener("click", () => this.editor.focusSelected());
    $("gridToggle").addEventListener("click", (e) => {
      const visible = this.editor.toggleGrid();
      e.currentTarget.textContent = `Grade: ${visible ? "ligada" : "desligada"}`;
    });
    $("objectSearch").addEventListener("input", (e) => this.renderTree(e.target.value));
    $("expandAll").addEventListener("click", () => this.renderTree());
    document.querySelectorAll("[data-tool]").forEach((button) => button.addEventListener("click", () => {
      document.querySelectorAll("[data-tool]").forEach((b) => b.classList.toggle("active", b === button));
      this.editor.setTool(button.dataset.tool);
      $("toolReadout").textContent = ({select:"Selecionar",move:"Mover",rotate:"Rotacionar",scale:"Escalar"})[button.dataset.tool];
    }));
    if (this.profile) this.showHub(); else $("welcome").classList.remove("hidden");
  }

  enter() {
    const name = $("profileName").value.trim();
    if (!name) return this.toast("Digite um nome para continuar.");
    this.profile = name;
    localStorage.setItem(PROFILE_KEY, name);
    this.showHub();
  }

  showWelcome() {
    $("hub").classList.add("hidden");
    $("editor").classList.add("hidden");
    $("welcome").classList.remove("hidden");
    $("profileName").value = this.profile;
  }

  showHub() {
    $("welcome").classList.add("hidden");
    $("editor").classList.add("hidden");
    $("hub").classList.remove("hidden");
    $("hubProfileName").textContent = this.profile || "Visitante";
    $("profileAvatar").textContent = (this.profile || "N").charAt(0).toUpperCase();
    this.renderProjects();
  }

  readProjects() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); }
    catch { return []; }
  }

  persistProjects() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(this.projects));
  }

  createProjectDialog() {
    this.showModal("Novo projeto", "Dê um nome ao seu projeto. Você poderá alterar esse nome depois.", "Nome do projeto", "Criar projeto", (name) => {
      const project = { id: crypto.randomUUID(), name, updatedAt: new Date().toISOString(), scene: null };
      this.projects.unshift(project);
      this.persistProjects();
      this.openProject(project.id);
    });
  }

  showModal(title, description, placeholder, action, callback) {
    const layer = $("modalLayer");
    layer.innerHTML = `<div class="modal"><h2>${this.escape(title)}</h2><p>${this.escape(description)}</p><input class="text-field" id="modalInput" maxlength="40" placeholder="${this.escape(placeholder)}"><div class="modal-actions"><button class="secondary-button" id="modalCancel">Cancelar</button><button class="primary-button compact" id="modalConfirm">${this.escape(action)}</button></div></div>`;
    layer.classList.remove("hidden");
    const input = $("modalInput"); input.focus();
    const close = () => layer.classList.add("hidden");
    $("modalCancel").onclick = close;
    $("modalConfirm").onclick = () => { const value = input.value.trim(); if (!value) return; close(); callback(value); };
    input.addEventListener("keydown", (e) => { if (e.key === "Enter") $("modalConfirm").click(); });
  }

  renderProjects() {
    const grid = $("projectGrid");
    grid.innerHTML = "";
    $("projectCount").textContent = `${this.projects.length} ${this.projects.length === 1 ? "projeto" : "projetos"}`;
    $("emptyState").classList.toggle("hidden", this.projects.length > 0);
    this.projects.forEach((project) => {
      const card = document.createElement("article");
      card.className = "project-card";
      const date = new Date(project.updatedAt).toLocaleDateString("pt-BR");
      card.innerHTML = `<div class="project-preview">◇</div><div class="project-info"><strong>${this.escape(project.name)}</strong><small>Modificado em ${date}</small></div>`;
      card.addEventListener("click", () => this.openProject(project.id));
      grid.appendChild(card);
    });
  }

  openProject(id) {
    const project = this.projects.find((p) => p.id === id);
    if (!project) return;
    this.activeProjectId = id;
    $("editorProjectName").textContent = project.name;
    $("hub").classList.add("hidden");
    $("editor").classList.remove("hidden");
    this.editor.mount($("viewport"), project.scene);
    this.renderTree();
    this.log(`Projeto "${project.name}" aberto.`);
  }

  backToHub() {
    this.saveActive();
    this.editor.unmount();
    this.showHub();
  }

  saveActive() {
    const project = this.projects.find((p) => p.id === this.activeProjectId);
    if (!project) return;
    project.scene = this.editor.serialize();
    project.updatedAt = new Date().toISOString();
    this.persistProjects();
    $("saveStatus").textContent = "Salvo neste dispositivo";
    this.renderProjects();
    this.toast("Projeto salvo neste dispositivo.");
  }

  markDirty() {
    $("saveStatus").textContent = "Alterações não salvas";
    const project = this.projects.find((p) => p.id === this.activeProjectId);
    if (project) project.scene = this.editor.serialize();
    this.renderTree();
  }

  renderTree(filter = "") {
    const tree = $("objectTree");
    if (!this.editor.scene) return;
    tree.innerHTML = "";
    const root = document.createElement("div");
    root.className = "tree-row";
    root.innerHTML = '<span class="tree-icon">▾</span><span class="tree-icon">◇</span><span>Workspace</span>';
    tree.appendChild(root);
    this.editor.getObjects().filter((obj) => obj.name.toLowerCase().includes(filter.toLowerCase())).forEach((obj) => {
      const row = document.createElement("div");
      row.className = `tree-row ${this.editor.selected === obj ? "selected" : ""}`;
      row.innerHTML = `<span class="tree-indent"></span><span class="tree-icon">▧</span><span>${this.escape(obj.name)}</span>`;
      row.addEventListener("click", () => { this.editor.select(obj); this.renderTree(filter); });
      tree.appendChild(row);
    });
    $("objectStatus").textContent = `${this.editor.getObjects().length} objetos`;
  }

  log(message) {
    const output = $("outputLog");
    const line = document.createElement("div");
    line.textContent = `[${new Date().toLocaleTimeString("pt-BR")}] ${message}`;
    output.appendChild(line);
    output.scrollTop = output.scrollHeight;
  }

  toast(message) {
    const toast = $("toast");
    toast.textContent = message;
    toast.classList.remove("hidden");
    clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => toast.classList.add("hidden"), 2300);
  }

  escape(value) {
    return String(value).replace(/[&<>"']/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  }
}
