import { StudioApp } from "./studio.js";

const app = new StudioApp();
app.start();
